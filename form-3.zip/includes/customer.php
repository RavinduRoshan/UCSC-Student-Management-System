<?php
    class Customer{
        public $customer_code;
        public $customer_name;
        
        public function create_customer(){
            
        }
        
        public function buy(){
            
        }
        
        
    }
        
        
?>
