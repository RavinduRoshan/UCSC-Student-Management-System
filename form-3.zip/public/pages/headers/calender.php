<link type="text/css" rel="stylesheet" href="style.css">
                    <script type="text/javascript" src="script.js"></script>
                    
                    <div class="panel panel-default navbar-collapse">
                        <div class="panel-heading">
                            <i class="fa fa-calendar"></i>  Calendar
                        </div>
                             
                        <div class="panel-body" style="padding-left: 1px">
                            <div id="calendar-container">
                            <div id="calendar-header">
                                <span id="calendar-month-year"></span>
                            </div>
                            <div id="calendar-dates"></div>
                        </div>
                        </div>
                        <div class="panel-footer">
                            
                        </div>
                    </div>